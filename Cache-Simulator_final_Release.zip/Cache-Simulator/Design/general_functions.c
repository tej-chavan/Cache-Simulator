/*--------------------------------------------------------------------------------------------------
general_functions.c : 
Contains functions for simulation of Instruction Cache.
-bits_cal    => This function calculates the line size and index size 
-Index_split => This function splits the index from the input address
-Mesi_states => This function returns the value of the MESI states


 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-----------------------------------------------------------------------------------------------------*/
// Defining Required libraries

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>

// Defining required functions files
#include "cache_parameters.h"
extern int event,line_size,index_size;
extern int tag,index_l,byte_select;
extern int a,b,c,d;
extern uint32_t address;
//--------------------------------------------------------------------------------------------------
void bits_cal()
{
    if(event != 2)
{
        a = ADDRESS_BITS - D_line_bits;
        b = ADDRESS_BITS - (D_index_bits + D_line_bits);
        c = ADDRESS_BITS - D_index_bits;
        d = D_line_bits + D_index_bits;
}
else
{
        a = ADDRESS_BITS - I_line_bits;
        b = ADDRESS_BITS - (I_index_bits + I_line_bits);
        c = ADDRESS_BITS - I_index_bits;
        d = I_line_bits + I_index_bits;
}
}


//---------------Split Index Bits from the address-----------------------------------------------------
// Splits or Masks the the Index Bits from the netire address 
void Index_Split ()
	{
    bits_cal ();
    byte_select = (address << a) >> a;
	// Now we can operate on our leftover address which is without the Byte_Sel bits
    index_l = (address << b) >> c;
    tag = (address >> d);
    address = address - byte_select;
	}


//----------------------------------------------------------------------------------------------------s
char mesi_state(int mesi_int)
{
    switch (mesi_int) {
        case M:
            return 'M';
            break;
        case E:
            return 'E';
            break;
        case S:
            return 'S';
            break;
        case I:
            return 'I';
            break;
        default:
            break;
    }return 'E';
}




