/* ------------------------------------------------------------------
Header File for General_Functions.c

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------------*/
#include <stdio.h>
#include "cache_parameters.h"

#define MAX_LINE_SIZE 1000

//#define General_Functions

// Variable to declare Index Split bits
void Index_Split ();

void bits_cal();

char mesi_state(int mesi_int);
