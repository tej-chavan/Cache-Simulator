/*
 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
 */

#include <stdio.h>
#include <stdlib.h>
#include "data_cache_functions.h"
#include "cache_parameters.h"

extern int mode_sel;

extern int way;

extern struct cacheline Data_Cache[D_SETS][D_WAY];

extern int evict_flag ;

void
MESI (int event, int index, int address)
{
    switch (event)
    
    {
            
        case D_L1_Read:
            
            switch (Data_Cache[index][way].MESI)
            
        {
                
            case I:
            {
                
                Data_Cache[index][way].MESI = S;
                
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "Read from L2               <0x%08x>\n", address);
                    
                }
                break;
                
            }
                
            case S:
            {
                
                break;
                
            }
                
            case E:
            {
                if (evict_flag==1) {
                    Data_Cache[index][way].MESI = S;
                }
                break;
                
            }
                
            case M:
            {
                if (evict_flag==1) {
                    Data_Cache[index][way].MESI = S;
                }
                
                break;
                
            }
                
                
            default:
            {
                
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "PROTOCOL VIOLATION\n");
                    
                }
                
                break;
                
            }
                
        }
            
            break;
            
            
        case D_L1_Write:
            
            switch (Data_Cache[index][way].MESI)
        {
                
            case I:
            {
                
                Data_Cache[index][way].MESI = E;
                
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "Read for Ownership from L2 <0x%08x>\n",
                             address);
                    fprintf (outfile, "Write to L2                <0x%08x>\n",
                             address);
                    
                }
                
                break;
                
            }
                
                
            case S:
            {
                
                Data_Cache[index][way].MESI = E;
                
                if (mode_sel == 1)
                {
                    fprintf (outfile, "Write to L2                <0x%08x>\n"
                             ,address);
                }
                break;
                
            }
                
                
            case E:
            {
                if (evict_flag==1) {
                Data_Cache[index][way].MESI = E;
                }
                else{
                Data_Cache[index][way].MESI = M;
                }
                break;
                
            }
                
                
            case M:
            {
                if (evict_flag==1) {
                    Data_Cache[index][way].MESI = E;
                }
                break;
                
            }
                
                
            default:
            {
                
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "PROTOCOL VIOLATION\n");
                }
                
                break;
                
            }
                
        }
            
            break;
            
            
            
        case I_L1_READ:
            
            switch (Data_Cache[index][way].MESI)
            
        {
                
            case I:
            {
                
                Data_Cache[index][way].MESI = S;
                
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "Read from L2                <0x%08x>\n"
                             ,address);
                    
                }
                
                break;
                
            }
                
                
            default:
                if (mode_sel == 1)
                {
                    
                    fprintf (outfile, "PROTOCOL VIOLATION\n");
                    
                }
                
                break;
                
        }
            
            break;
            
            
            int temp_way;
            
            
        case D_L2_Read:
            
        {
            
            for (temp_way = 0; temp_way < D_WAY; temp_way++)
                
            {
                
                if (Data_Cache[index][temp_way].TAG == tag)
                    
                    break;
                
            }
            
            
            switch (Data_Cache[index][temp_way].MESI)
            
            {
                    
                case M:
                    
                {
                    
                    Data_Cache[index][temp_way].MESI = S;
                    
                    if (mode_sel == 1)
                    {
                        
                        fprintf (outfile, "Return data to L2                <0x%08x>\n",
                                 address);
                        
                    }
                    
                }
                    break;
                    
                    
                case E:
                    
                {
                    
                    Data_Cache[index][temp_way].MESI = S;
                    
                }
                    break;
                    
                    
                default:
                    if (mode_sel == 1)
                    {
                        
                        fprintf (outfile, "PROTOCOL VIOLATION\n");
                        
                    }
                    
                    break;
                    
            }
            
        }
            
            break;
            
            
        case INVALIDATE:
            
        {
            
            for (int temp_way = 0; temp_way < D_WAY; temp_way++)
                
            {
                if (Data_Cache[index][temp_way].TAG == tag)
                    
                {
                    if ((Data_Cache[index][temp_way].MESI == S)
                        || (Data_Cache[index][temp_way].MESI == E) || (Data_Cache[index][temp_way].MESI == I))
                        
                    {
                        Data_Cache[index][temp_way].MESI = I;
                        break;
                        
                    }
                    else
                        
                        if (mode_sel == 1)
                        {
                            
                            fprintf (outfile, "PROTOCOL VIOLATION\n");
                            break;
                            
                        }
                    
                }
                
            }
        }
            break;
            
            
        default:
        {
            
            if (mode_sel == 1)
            {
                
               fprintf (outfile, "PROTOCOL VIOLATION\n");
                
            }
            
            break;
            
        }
            
    }
    
}



