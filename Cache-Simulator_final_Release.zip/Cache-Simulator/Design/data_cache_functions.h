/* ------------------------------------------------------------------
Header File for General_Functions.c

 Authors:
 @Ajna Bindhu,
 @Sai T Bodanki
 @Suraj A Sathyanarayanan
 @Tejas Chavan
-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include "cache_parameters.h"

//#define General_Functions

extern FILE *outfile;
extern int Index_Bits;
extern int Byte_Sel;
extern int way,tag;
extern struct cacheline Data_Cache[D_SETS][D_WAY];
extern int d_hit, d_miss;
extern uint32_t address;
extern int mode_sel,byte_select;
extern int evict_flag;
extern int event;

// Variable to Match tag bits
//int Match_Tag_Bits(int index, int tag, int *hit);

void D_updateLRU(int index, int way);

void D_Clear_Cache(void);

int D_Miss_Handler(int index, int tag);

int D_Hit_Check(int index, int tag);

int Data_Read(int index, int tag);

void D_Evict_Line_LRU(int index, int tag);

void D_Statistics();

void MESI(int event, int index, int address);

unsigned long get_address(int index, int way);




