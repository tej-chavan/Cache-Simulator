/*---------------------------------------------------------------------------------------------------------------------
 DESCRIPTION : 
 - This program simulates the L1- Split cache along with higher level L2 cache for a processor along with
   3 other processors in a shared bus configuration.
 - The L1 Cache has been split into L1-I-Cache and L1-D-Cache. 
 - L1 instruction cache	is	two-way	set	associative	and	consists of	16K	sets and 64-byte lines.
 - L1 data cache is	four-way set associative and consists of 16K sets of 64-byte lines and used write through pplocy 
   on first write and write Back on all subsequent writes.
 - Both caches employ LRU replacement policy backed by L2 cache and employs inclusivity.


 Authors: Bindu Ajna
 Bodanki Sai Teja
 Chavan Tejas
 Sathyanarayanan Suraj
 ---------------------------------------------------------------------------------------------------------------------*/


// Declaring Standard Libraries
#include <stdio.h>
#include <stdlib.h>
#include "cache_parameters.h"
#include "general_functions.h"
#include "instruction_cache_functions.h"
#include "data_cache_functions.h"
#include <string.h>

//**********************************DEFINITIONS*********************************************
//File Acess
FILE *outfile;        				//  Output File pointer
FILE *infile;            			//  Input File Pointer
// Defining 2 char pointers to take input and output file names.
char line[MAX_LINE_SIZE + 1];    // ptr to the current input line
const char s[2] = " ";
const char *input;
const char *output;
char *token;
int arr[2];
int i;
const char *mode;                    // pointer for MODE select
//Global Variables
int event;
uint32_t address;
int a,b,c,d;
int d_rd, d_wr, i_rd = 0;			// Initialization of read and write count 
int i_hit = 0, d_hit = 0;           // Variable for Hit count initialized to 0
int i_miss = 0, d_miss = 0;			// Variable for miss count initialized to 0
int way,tag,index_l,byte_select;
int line_size, index_size;			// Variable for line size and Index size
int mode_sel;
int evict_flag;						// Return value from Evict_flag function
//********************************CACHE BLOCK STRUCTURES****************************************************
// Declaring Structure For Instruction Cache
struct cacheline Instr_Cache[I_SETS][I_WAY];
struct cacheline Data_Cache[D_SETS][D_WAY];

//******************************* MAIN FUNCTION *************************************************************

// Declaration of Main Function
int main (int argc, char *argv[])
{
    // I/O files are taken using Command Line arguments
    // Case 1 : No file names , modes are mentioned.
    if (argc == 1)
    {
        
        printf
        ("I/O files,modes are not mentioned. Using Mode 0 with default files as Inputs and Outputs \n");
        
        input = "Cache_fill.txt";
        
        output = "output.txt";
        
        mode = "0";
        
    }
    
    // Case 2 : Only Input File name is provided. Default Output file is created.
    else if (argc == 2)
        
    {
        
        printf
        ("Running in mode 0 Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
        
        input = argv[1];
        
        mode = "0";
        
        output = "output.txt";
        
    }
    
    // Mode selection. ss
    else if (argc == 3)
        
    {
        
        printf
        ("Runnning in mode specified, Input file will be named as mentioned. Output file will be defaulted to output.txt\n");
        
        input = argv[1];
        
        mode = argv[2];
        
        output = "output.txt";
        
    }
    
    // Case 3 : Both Input and Output file names are mentioned
    else
        
    {
        
        input = argv[1];
        
        mode = argv[2];
        
        output = argv[3];
        
    }
    
    // Opening Input and Output file in read and write mode respectively
    infile = fopen (input, "r");    // Read Mode
    outfile = fopen (output, "w");    // Write Mode
    
    // Clear both Instruction and Data cache on startup
    I_Clear_Cache ();
    D_Clear_Cache ();
    
    //Mode Converstion to int;
    char mode_char = *mode;
    mode_sel = (int) mode_char - 48;
    
    // Read the input file line by line for trace instructions and process them 
    while (fgets (line, sizeof (line), infile) != NULL)
    {
        
        
        if (feof (infile))
            
            break;
        
        if (line[0] != '\n')
        {
            
            i = 0;
            
            token = strtok (line, s);
            
            while (token != NULL)
            {
                
                arr[i] = (int) strtol (token, NULL, 16);
                
                token = strtok (NULL, s);
                
                i++;
                
            }
            event = arr[0];
            
            address = arr[1];
            
            // Split Address
            
            Index_Split ();
            
            //int tag_bits =  8*sizeof(address) - tag_rem;
            
            evict_flag = 0;

//**********************************  EVENT HANDLER **************************************************
            //Detect and report invalid event
            if ((event > 4) && (event < 8))
                
            {
                
                fprintf (outfile, "Invalid Event\n");
                
                continue;
                
            }
            
            //Detect L1 Data reads
            else if (event == D_L1_Read)
                
            {
                
                if ((Data_Read (index_l, tag)))
                {
                    
                    d_hit++;									
                    
                }
                
                else
                {
                    
                    d_miss++;									
                    
                }
                
                MESI (event, index_l, address);
                
            }
            
            //Detect L1 Data writes
            else if (event == D_L1_Write)
                
            {
                
                if ((Data_Read (index_l, tag)))
                {
                    
                    d_hit++;
                    
                }
                
                else
                {
                    
                    d_miss++;
                    
                }
                
                MESI (event, index_l, address);
                
            }
            
            // Detect L1 Instruction read
            else if (event == I_L1_READ)
                
            {
                
                if ((Instruction_Read (index_l, tag)))
                {
                    
                    i_hit++;
                    
                }
                
                else
                {
                    
                    i_miss++;
                    
                }
                
                
            }
            
            
            
            // Data request from L2 (in response to snoop)
            else if (event == D_L2_Read)
                
            {
                
                MESI (event, index_l, address);
                
            }
            
            
            
            //Detect INVALIDATE command from L2
            else if (event == INVALIDATE)
                
            {
                
                MESI (event, index_l, address);
                
            }
            
            
            //Detect reset event
            else if (event == RESET)
                
            {
                i_hit = 0;
                i_miss = 0;
                
                d_hit = 0;
                d_miss = 0;
                
                I_Clear_Cache ();
                
                D_Clear_Cache ();
                
                continue;
                
            }
            
            
            //Detect cache display event
            else if (event == PRINTALL)
                
            {
                fprintf(outfile,"\n");
                I_Statistics();
                fprintf(outfile,"\n");
                D_Statistics();
                fprintf(outfile,"\n");
                continue;
                
            }
            
        }
        
        
    }
    
// ******************************** HIT and MISS ratio *************************************************    
    float i_hit_ratio = 0;
    
    float d_hit_ratio = 0;
    
    
    if (i_miss > 0)
    {
        
        i_hit_ratio = ((float) (i_hit)) / ((float) (i_miss) + (float) (i_hit));
        
    }
    
    
    if (d_miss > 0)
    {
        
        d_hit_ratio = ((float) (d_hit)) / ((float) (d_miss)+(float) (d_hit));
        
    }
    
    
    fclose (infile);
    
    fclose (outfile);
    
   
  // ***************************** PRINT STATISTICS **************************************************
    
    printf ("\n-------------Instruction Cache Stats---------\n");
    
    printf (" CPU Requests : %d \n", i_hit+i_miss);
    
    printf (" Hits : %d \n", i_hit);
    
    printf (" Miss : %d \n", i_miss);
    
    printf (" Hit Ratio : %3f", i_hit_ratio);
    
    
    printf ("\n-------------Data Cache Stats---------\n");
    
    printf (" CPU Requests : %d \n", d_hit+d_miss);
    
    printf (" Hits : %d \n", d_hit);
    
    printf (" Miss : %d \n", d_miss);
    
    printf (" Hit Ratio : %3f\n", d_hit_ratio);
    
    getchar ();
    
}


